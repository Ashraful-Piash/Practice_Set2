package com.piash;

public class Calculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte num1=90;
		byte num2=10;
		int addition = num1+num2;
		int subtraction = num1-num2;
		int multiplication = num1*num2;
		int division = num1/num2;
		
		
    System.out.println("Addition :" +addition);
    System.out.println("Subtraction :"+subtraction);
    System.out.println("Multiplication :"+multiplication);
    System.out.println("Division :"+division);
    
	}

}
