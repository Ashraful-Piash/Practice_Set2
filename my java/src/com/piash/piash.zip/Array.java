package com.piash;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] number = new int[5];

		number[0] = 15;
		number[1] = 20;
		number[2] = 28;
		number[3] = 39;
		number[4] = 40;
		
		int sum = number[0]+number[1]+number[2]+number[3]+number[4];
		System.out.println("Sum of array :" +sum);
		int len = number.length;
		System.out.println("Length of array:" +len);
		
				
	}
}